package com.onedumall.mapper;

public class Mapper {

	
	private int name;
}
